const button = document.querySelector('button');
const image = document.getElementById('target-image');

button.addEventListener('click', () => {
    image.src = "fluacu.jpg"; // Replace with your actual image source
    image.style.display = 'block';
});
